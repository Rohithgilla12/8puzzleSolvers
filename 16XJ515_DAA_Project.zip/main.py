from bfs import *
from bidir import *
from bfs import *
from dls import *
from ids import *
from temp import *
from ucs import *
from astar import *

# All codes final out put are called in repective programs only so no need to write a main.py again